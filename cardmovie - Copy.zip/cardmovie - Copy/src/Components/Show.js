import "./Show.css";
import { useState } from "react";

const Show = () => {
  const [modalOpen, setVisibility] = useState([false]);
  const loadLogin = () => {
    debugger;
    setVisibility(true);
  };
  const closeModal = () => {
    debugger;
    setVisibility(false);
  };

  return (
    <>
      <div class="topnav">
        <a class="active" href="#home">
          Home
        </a>
        <a href="#" onClick={loadLogin}>
          LOGIN
        </a>
        <a href="#" onClick={loadLogin}>
          Sign Up
        </a>
      </div>
      {modalOpen && <div className="overlay" onClick={closeModal} />}
      {modalOpen && (
        <div className="modal">
          <h2>User Login</h2>
          <label>Username: </label>
          <input type="text"></input>
          <br></br>
          <label>Password: </label>
          <input type="password"></input>
          <br></br>
          <button onClick={closeModal}>Close</button>
        </div>
      )}
      ;
    </>
  );
};

export default Show;
