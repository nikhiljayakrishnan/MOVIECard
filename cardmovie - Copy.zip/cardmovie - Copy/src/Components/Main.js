function Main() {
  return (
    <div>
      <h1>asd asd asd</h1>
    </div>
  );
}

export default Main;
