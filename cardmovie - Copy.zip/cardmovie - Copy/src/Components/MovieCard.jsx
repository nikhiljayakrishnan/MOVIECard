import "./MovieCard.css";
import pic from "../images/shawshank.jpg";
export const MovieCard = ({ movi }) => {
  const { image, movie, rating } = movi;
  console.log([{ movi }]);

  const path = () => {
    console.log(pic);
    console.log(image);
  };
  const pat = "/static/media/shawshank.e0b75aca957d0935f3ea.jpg";
  //cardmovie\src\Components\images\shawshank.jpg
  console.log(`--------XOP-- \n -----${image}----- \n -----------`);
  console.log(`--------XOP1-- \n -----${pic}----- \n -----------`);
  return (
    <div className="card-container">
      <div className="card-img-container">
        <img src={`${process.env.PUBLIC_URL}/${image}`} alt={path} />
      </div>
      <div className="card-details">
        <div>
          <span> Name: {movi.movie}</span>
        </div>
        <div>
          <span>Genre: drama,crime</span>
        </div>
        <div>
          <span>Ratings: {rating}</span>
        </div>
      </div>
    </div>
  );
};
