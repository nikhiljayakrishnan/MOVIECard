import Show from "./Components/Show";
import logo from "./logo.svg";
import "./App.css";
import { useEffect, useState } from "react";
import axios from "axios";
import { MovieCard } from "./Components/MovieCard";

function App() {
  const [movie, setMovie] = useState([]);
  const getMovies = async () => {
    try {
      console.log("Here!!");
      //https://movies-app.prakashsakari.repl.co/api/movies
      const { data } = await axios.get("https://dummyapi.online/api/movies");
      // const { data } = await axios.get(
      //   "https://movies-app.prakashsakari.repl.co/api/movies"
      // );
      //const convertedData = await data.json();
      setMovie(data);
      console.log(data);
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(function () {
    getMovies();
  }, []);

  return (
    <div>
      <Show />

      <div className="App">
        <h1>MOVIES</h1>
        <main className="main">
          {movie &&
            movie.length > 0 &&
            movie.map((movi) => <MovieCard key={movi.id} movi={movi} />)}
        </main>
      </div>
    </div>
  );
}

export default App;
